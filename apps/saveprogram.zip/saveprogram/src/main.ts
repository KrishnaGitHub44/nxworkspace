//import { v4 as uuidv4 } from 'uuid';
//import uuid from 'crypto';
import express from 'express';
import { randomUUID } from 'crypto';
//import { json } from 'stream/consumers';
//import { products } from './products';
import { scheduleJob } from 'node-schedule'



const host = process.env.HOST ?? 'localhost';
const port = process.env.PORT ? Number(process.env.PORT) : 3000;

const saveEnergyApp = express();

// dailyJobRunner to increament simulated date and update the deposites to balance

let lastSimulatedDay = -1;
(async function() {
    scheduleJob('*/1 * * * *', async function() {
        lastSimulatedDay += 1
        console.log("running",lastSimulatedDay)
        const dailyJobs = new updateDaily(lastSimulatedDay);
        dailyJobs.updateDepositsDaily(lastSimulatedDay);
        dailyJobs.updateProductsDaily(lastSimulatedDay)
        //updateDepositsDaily(Deposits)
        //updatedProductsDaily()
        //console.log("Deposits:",Deposits)
        console.log("Accounts:",Accounts)
        console.log("Products:", products)
        console.log("Purchases:",Purchases)
    });
})();

// ****** Adding the products here as the import is giving me an error ********

interface product
  {
    id: string,
    title: string,
    description: string,
    stock: number,
    price: number,
    simulatedday?:number
  }
const products:product[] = [
  {
    id: "solar",
    title: "Solar Panel",
    description: "Super duper Essent solar panel",
    stock: 10,
    price: 750,
  },
  {
    id: "insulation",
    title: "Insulation",
    description: "Cavity wall insulation",
    stock: 10,
    price: 2500,
  },
  {
    id: "heatpump",
    title: "Awesome Heatpump",
    description: "Hybrid heat pump",
    stock: 3,
    price: 5000,
  },
];
interface Account {
  id: string,
  name: string,
  balance: number
}

const Accounts:Account[] = [];
saveEnergyApp.use(express.json());

// Function to check if the input is empty
const Empty = (payload:string | Account | Deposit[] | purchase | JSON) => {
  return Object.keys(payload).length === 0;
}

// Function to filter based on accountId.

const filterAccount = (accountId: string) =>{
  const indx = Accounts.findIndex(Object => {
    return Object.id === accountId
  });
  if (indx !== -1) {
  
  return Accounts[indx];
  };
};

// *********** PART A ***************
saveEnergyApp.post('/accounts', (req, res) => {
//const requestmessage = req.body;
//console.log(req.body);
const isEmpty = Object.keys(req.body).length === 0;

if ( !isEmpty ) {
  const responseData:Account = {id:randomUUID(), name:req.body.name, balance: 0}
  Accounts.push(responseData)
  console.log(Accounts)
  //res.statusMessage = 'Success'
  res.send(responseData);
}
else { 
  res.statusMessage = 'Invalid Input';
  res.status(400).end();
  //res.send();
}
});

saveEnergyApp.get('/accounts', (req, res) => {
  res.status(201)
  //res.statusMessage =  'Success'
  res.send(Accounts);
});

saveEnergyApp.get('/accounts/:accountId', (req, res) => {
  const AccountId = req.params.accountId;
  const indx = Accounts.findIndex(Object => {
    return Object.id === AccountId
  })
  if (indx !== -1){
    res.status(200)
    res.send(Accounts[indx])
  } else {
    res.statusMessage = 'Not Found'
    res.status(404).end();
  }
})

// ********* PART B ***************
interface Deposit {
  id:string,
  accountid:string,
  amount: number,
  simulatedday:number,
  completed:boolean
}

const Deposits:Deposit[] = [];

class updateDaily {
  simulatedday:number
  constructor(simulatedday:number){
    this.simulatedday = simulatedday
  }
  updateDepositsDaily(simulatedday:number):void {

    if(!Empty(Deposits)) {
    const depositesUpdate = Deposits.filter((Object) => { 
      return Object.simulatedday <= simulatedday && Object.completed === false;
    })
    console.log(depositesUpdate);
    depositesUpdate.forEach((deposit) => {
      const indx = Accounts.findIndex((Object) => {
        return Object.id === deposit.accountid
      });
      Accounts[indx].balance += deposit.amount
    })
    const indx = Deposits.findIndex((Object) => {
      return Object.completed === false
    });
    if (indx !== -1) {
    Deposits[indx].completed = true;
    }
    }
  }

  updateProductsDaily(simulatedday:number):void {
      products.forEach((product, index) => {
        products[index].simulatedday = simulatedday
      })
  }
}
/*
const updateDepositsDaily = (Deposits:Deposit[]) =>{

  if(!Empty(Deposits)) {
  const depositesUpdate = Deposits.filter((Object) => { 
    return Object.simulatedday <= lastSimulatedDay && Object.completed === false;
  })
  console.log(depositesUpdate);
  depositesUpdate.forEach((deposit) => {
    const indx = Accounts.findIndex((Object) => {
      return Object.id === deposit.accountid
    });
    Accounts[indx].balance += deposit.amount
  })
  const indx = Deposits.findIndex((Object) => {
    return Object.completed === false
  });
  if (indx !== -1) {
  Deposits[indx].completed = true;
  }
}
}
const updatedProductsDaily = () => {
  products.forEach((product, index) => {
    products[index].simulatedday = lastSimulatedDay
  })
}
*/
saveEnergyApp.post('/accounts/:accountId/deposits', (req, res) => {
  if(!Empty(req.body)) {
    const filteredAccData = filterAccount(req.params.accountId)
    if(!Empty(filteredAccData)){
      const simdayheader = parseInt(String(req.headers['simulated-day']));
      console.log(simdayheader)
      const depositId= randomUUID();
      const inputData:Deposit= {id:depositId, accountid:filteredAccData.id, amount:req.body.amount, simulatedday: simdayheader,completed: false}
      console.log(inputData);
      Deposits.push(inputData)
      res.status(201)
      res.send({id:depositId, name:filteredAccData.name, balance: filteredAccData.balance})
    } else {
      res.statusMessage = 'Account does not exist ';
      res.status(400).end();
    }
  } else {
    res.statusMessage = 'Invalid Input';
    res.status(400).end();
  }
})

const filterProducts = (productId:string) => {
  const indx = products.findIndex(Object => {
    return Object.id === productId
  })
  return indx;
}

interface purchase {
  accountId : string, // accountId
  productId: string,
  price: number,
  simulatedday: number  
}

const Purchases:purchase[] = [{accountId: '123',productId: '12345', price: 200, simulatedday: 2}];

const filterPurchases = (accountId:string) => {
  //const indx = Purchases.find((Object) => Object.accountId === accountId)
  const max = Purchases.reduce((prev, current) => ((prev && prev.simulatedday > current.simulatedday),prev.accountId === accountId) ? prev : current)
  console.log(max)
  return max
}

saveEnergyApp.post('/accounts/:accountId/purchases', (req, res) => {
  const customerId = req.params.accountId;
  if(!Empty(req.body)) {
    const filteredAccData = filterAccount(customerId)
    const lastpurchase = filterPurchases(customerId)
    console.log("Lastpurchase indx:",lastpurchase);
    //const depositeDetails = filterDeposites (req.params.accountId)
    if(!Empty(filteredAccData)){
      const simdayheader = parseInt(String(req.headers['simulated-day']));
      console.log(simdayheader)
      let lastpurchasesimday = 0;
      if (!Empty(lastpurchase)){
        lastpurchasesimday = lastpurchase.simulatedday
      }
      const productindx = filterProducts(req.body.productId)

     /* ******* This is handled in Daily Job Runner **********

       const depositesWithId = Deposits.filter((Object) => { 
        return Object.accountid === req.params.accountId && Object.simulatedday < simdayheader;
      })
      console.log(depositesWithId);
      const totaldeposites = depositesWithId.reduce((total,Item) => {
        return total + Item.amount;
      }, 0) */

      const purchasesWithId = Purchases.filter((Object) => {
        return Object.accountId === customerId;
      })
      const totalpurchases = purchasesWithId.reduce((total,Item) => {
        return total+Item.price;
      },0 )

      const outstandingbal = filteredAccData.balance - totalpurchases;
      console.log("outbal",outstandingbal, "totaldep",filteredAccData.balance, "totalpurchase",totalpurchases, "productprice",products[productindx].price)
      if(products[productindx].stock >= 1 ) {

        if ( lastpurchasesimday < simdayheader && lastSimulatedDay < simdayheader) {
          if (outstandingbal > products[productindx].price) {
            const inputData:purchase= {accountId:req.params.accountId, productId:products[productindx].id, price:products[productindx].price, simulatedday: simdayheader}
            Purchases.push(inputData)
            //console.log(products[productindx].stock)
            products[productindx].stock -= 1
            //console.log(products[productindx].stock)
            res.sendStatus(201)
          } else {
            res.statusMessage = 'Not enough funds';
            res.sendStatus(409).end();
          }
        } else {
           res.statusMessage = 'Illegal Sim Day'
           res.sendStatus(400).end()
        }
      } else {
        res.statusMessage = 'Not enough stock'
        res.sendStatus(409).end();
      }
    }  else {
      res.statusMessage = 'Account does not exist ';
      res.status(400).end();
    }
  } else {
    res.statusMessage = 'Invalid Input';
    res.status(400).end();
  }
})

saveEnergyApp.post('/products', (req, res) => {
  if(!Empty(req.body)) {
    const inputProduct:product = {id:randomUUID(), title:req.body.title, description:req.body.description, stock: req.body.price, price: req.body.price}
    console.log(inputProduct);
    products.push(inputProduct)
    res.status(201).end()

  } else {
    res.statusMessage = 'Invalid Input';
    res.status(400).end();
  }
})

saveEnergyApp.get('/products', (req, res) => {

  const productsWithSimulated = products.filter((product) => {
    return product.simulatedday <= lastSimulatedDay
  })
  res.send(productsWithSimulated)
})

saveEnergyApp.listen(port, host, () => {
  console.log(`[ ready ] http://${host}:${port}`);
});

// res.status(200).send(`Hello World', ${Date.now()}`);
// npx nodemon app.js
// npx tsc --watch